<?php

namespace App\Console\Commands;
use App\Models\Order;
use Carbon\Carbon;

use Illuminate\Console\Command;

class DeleteUnverifiedOrders extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     *
     */
    protected $signature = 'app:delete-unverified-orders';

    protected $description = 'Delete orders with verify=0 older than 5 minutes';

    /**
     * The console command description.
     *
     * @var string
     */
 //   protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cutoff = Carbon::now()->subMinutes(5);

        $deleted = Order::where('is verify', 0)
            ->where('created_at', '<', $cutoff)
            ->delete();

        $this->info("Deleted $deleted unverified orders older than 5 minutes.");

    }
}
